-- ============================================================
--  Two-handed Analog Clock for Conky
--  • Outer ring with 60 minute/hour tick marks
--  • Hour hand  (thick, white, rounded cap)
--  • Minute hand (thinner, white, rounded cap)
--  • DAY  window — inside dial, upper half  (~11–1 o'clock zone)
--  • DATE window — inside dial, lower half  (~5–7 o'clock zone)
-- ============================================================

require 'cairo'

-- ── Tuneable settings ───────────────────────────────────────

-- Clock geometry
local cx      = 110    -- centre X inside the Conky window
local cy      = 110    -- centre Y inside the Conky window
local radius  = 95     -- outer edge of the clock face

-- Hour hand
local hh_length = 0.50   -- fraction of radius
local hh_width  = 6
local hh_r, hh_g, hh_b, hh_a = 1.0, 1.0, 1.0, 1.0

-- Minute hand
local mh_length = 0.82
local mh_width  = 3
local mh_r, mh_g, mh_b, mh_a = 1.0, 1.0, 1.0, 0.95

-- Outer ring
local ring_width = 2.5
local ring_r, ring_g, ring_b, ring_a = 1.0, 1.0, 1.0, 0.85

-- Tick marks
local tick_major_len = 13   -- every 5 min  (hour positions)
local tick_minor_len =  6   -- every 1 min
local tick_major_w   =  2.5
local tick_minor_w   =  1.0
local tick_r, tick_g, tick_b, tick_a = 1.0, 1.0, 1.0, 0.80

-- Centre dot
local dot_radius = 5
local dot_r, dot_g, dot_b, dot_a = 1.0, 1.0, 1.0, 1.0

-- ── In-dial box layout ──────────────────────────────────────
--
--   DAY  box  — centred on the upper half of the dial
--   DATE box  — centred on the lower half of the dial
--
--   Both boxes sit well inside the outer ring and clear the
--   hand pivot area in the middle.

local box_w     = 88    -- box width  (must fit inside the chord at that height)
local box_h     = 20    -- box height
local box_r     =  4    -- corner radius for the rounded rectangle
local font_face = "DejaVu Sans"

-- Vertical offsets from the dial centre  (positive = downward)
-- ~38 % of radius keeps the boxes clear of the hands and each other
local day_offset  = -radius * 0.42   -- upper half
local date_offset =  radius * 0.42   -- lower half

-- Derived top-left corners (boxes are horizontally centred on cx)
local day_box_x  = cx - box_w / 2
local day_box_y  = cy + day_offset  - box_h / 2

local date_box_x = cx - box_w / 2
local date_box_y = cy + date_offset - box_h / 2

-- ── Helper: rounded rectangle path ──────────────────────────
local function rounded_rect(cr, x, y, w, h, r)
    cairo_move_to(cr, x + r, y)
    cairo_line_to(cr, x + w - r, y)
    cairo_arc(cr, x + w - r, y + r,     r, -math.pi / 2,  0)
    cairo_line_to(cr, x + w, y + h - r)
    cairo_arc(cr, x + w - r, y + h - r, r,  0,            math.pi / 2)
    cairo_line_to(cr, x + r, y + h)
    cairo_arc(cr, x + r,     y + h - r, r,  math.pi / 2,  math.pi)
    cairo_line_to(cr, x, y + r)
    cairo_arc(cr, x + r,     y + r,     r,  math.pi,      3 * math.pi / 2)
    cairo_close_path(cr)
end

-- ── Helper: centred text inside a box ───────────────────────
local function draw_label(cr, text, box_x, box_y, font_size, r, g, b, a)
    cairo_select_font_face(cr, font_face,
        CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD)
    cairo_set_font_size(cr, font_size)
    cairo_set_source_rgba(cr, r, g, b, a)
    local te = cairo_text_extents_t:create()
    cairo_text_extents(cr, text, te)
    -- Pixel-perfect horizontal & vertical centering
    local tx = box_x + (box_w - te.width)  / 2 - te.x_bearing
    local ty = box_y + (box_h + te.height) / 2 - te.y_bearing - te.height
    cairo_move_to(cr, tx, ty)
    cairo_show_text(cr, text)
end

-- ── Helper: draw a clock hand ────────────────────────────────
local function draw_hand(cr, angle, length, width, r, g, b, a)
    local x2 = cx + length * math.sin(angle)
    local y2 = cy - length * math.cos(angle)
    cairo_move_to(cr, cx, cy)
    cairo_line_to(cr, x2, y2)
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND)
    cairo_set_line_width(cr, width)
    cairo_set_source_rgba(cr, r, g, b, a)
    cairo_stroke(cr)
end

-- ── Main entry point called by Conky every update ────────────
function conky_clock_draw()
    if conky_window == nil then return end

    local cs = cairo_xlib_surface_create(
        conky_window.display,
        conky_window.drawable,
        conky_window.visual,
        conky_window.width,
        conky_window.height
    )
    local cr = cairo_create(cs)

    -- Current time
    local hours   = tonumber(os.date("%I"))   -- 12-hour format (1–12)
    local minutes = tonumber(os.date("%M"))

    -- ── 1. Outer ring ─────────────────────────────────────────
    cairo_arc(cr, cx, cy, radius, 0, 2 * math.pi)
    cairo_set_line_width(cr, ring_width)
    cairo_set_source_rgba(cr, ring_r, ring_g, ring_b, ring_a)
    cairo_stroke(cr)

    -- ── 2. Tick marks (60 total) ──────────────────────────────
    for i = 0, 59 do
        local angle     = (i / 60) * 2 * math.pi
        local is_major  = (i % 5 == 0)
        local t_len     = is_major and tick_major_len or tick_minor_len
        local t_wid     = is_major and tick_major_w   or tick_minor_w

        local xo = cx + radius           * math.sin(angle)
        local yo = cy - radius           * math.cos(angle)
        local xi = cx + (radius - t_len) * math.sin(angle)
        local yi = cy - (radius - t_len) * math.cos(angle)

        cairo_move_to(cr, xo, yo)
        cairo_line_to(cr, xi, yi)
        cairo_set_line_width(cr, t_wid)
        cairo_set_line_cap(cr, CAIRO_LINE_CAP_BUTT)
        cairo_set_source_rgba(cr, tick_r, tick_g, tick_b, tick_a)
        cairo_stroke(cr)
    end

    -- ── 3. DAY box (upper half of dial) ───────────────────────
    -- local day_str = os.date("%A")          -- e.g. "Saturday"
    local day_str = os.date("%a")          -- e.g. "Saturday"

    -- Semi-transparent dark fill
    rounded_rect(cr, day_box_x, day_box_y, box_w, box_h, box_r)
    cairo_set_source_rgba(cr, 0.05, 0.05, 0.10, 0.65)
    cairo_fill(cr)

    -- Border
    rounded_rect(cr, day_box_x, day_box_y, box_w, box_h, box_r)
    cairo_set_line_width(cr, 1.0)
    cairo_set_source_rgba(cr, 1, 1, 1, 0.55)
    cairo_stroke(cr)

    -- Warm-yellow centred text
    draw_label(cr, day_str, day_box_x, day_box_y, 11, 1.0, 0.90, 0.45, 1.0)

    -- ── 4. DATE box (lower half of dial) ──────────────────────
    -- local date_str = os.date("%d %b %Y")   -- e.g. "19 Sep 2026"
    -- local date_str = os.date("%d / %m / %Y")   -- e.g. "19 Sep 2026"
    -- local date_str = os.date("%A, %d %b") -- "Saturday, 19 Sep"
    local date_str = os.date("%d %b %y")   -- e.g. "19 Sep 2026"

    -- Semi-transparent dark fill
    rounded_rect(cr, date_box_x, date_box_y, box_w, box_h, box_r)
    cairo_set_source_rgba(cr, 0.05, 0.05, 0.10, 0.65)
    cairo_fill(cr)

    -- Border
    rounded_rect(cr, date_box_x, date_box_y, box_w, box_h, box_r)
    cairo_set_line_width(cr, 1.0)
    cairo_set_source_rgba(cr, 1, 1, 1, 0.55)
    cairo_stroke(cr)

    -- White centred text
    draw_label(cr, date_str, date_box_x, date_box_y, 11, 1.0, 1.0, 1.0, 1.0)

    -- ── 5. Hour hand ──────────────────────────────────────────
    -- Fractional offset so it sweeps continuously between hour marks
    local hour_angle = ((hours % 12) / 12 + minutes / 720) * 2 * math.pi
    draw_hand(cr, hour_angle, radius * hh_length, hh_width,
              hh_r, hh_g, hh_b, hh_a)

    -- ── 6. Minute hand ────────────────────────────────────────
    local min_angle = (minutes / 60) * 2 * math.pi
    draw_hand(cr, min_angle, radius * mh_length, mh_width,
              mh_r, mh_g, mh_b, mh_a)

    -- ── 7. Centre dot (drawn on top of both hands) ────────────
    cairo_arc(cr, cx, cy, dot_radius, 0, 2 * math.pi)
    cairo_set_source_rgba(cr, dot_r, dot_g, dot_b, dot_a)
    cairo_fill(cr)

    -- Cleanup
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end

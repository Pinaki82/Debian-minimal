-- ============================================================
--  Two-handed Analog Clock for Conky
--  • Hour hand  (thick, white)
--  • Minute hand (medium, white)
--  • 60 minute-tick marks (long ticks every 5 min / hour mark)
--  • Date box  (e.g. "19 Sep 2026")
--  • Day box   (e.g. "Saturday")
-- ============================================================

require 'cairo'

-- ── Tuneable settings ───────────────────────────────────────
local cx          = 110      -- Clock centre X (pixels from left edge of Conky window)
local cy          = 120      -- Clock centre Y (pixels from top  edge of Conky window)
local radius      = 90       -- Outer clock-face radius

-- Hour hand
local hh_length   = 0.55     -- fraction of radius
local hh_width    = 5
local hh_r, hh_g, hh_b, hh_a = 1.0, 1.0, 1.0, 1.0

-- Minute hand
local mh_length   = 0.85
local mh_width    = 3
local mh_r, mh_g, mh_b, mh_a = 1.0, 1.0, 1.0, 0.9

-- Outer ring
local ring_width  = 2
local ring_r, ring_g, ring_b, ring_a = 1.0, 1.0, 1.0, 0.8

-- Centre dot
local dot_radius  = 5
local dot_r, dot_g, dot_b, dot_a = 1.0, 1.0, 1.0, 1.0

-- Tick marks
local tick_major_len  = 12   -- every 5 minutes (hour positions)
local tick_minor_len  = 6    -- every 1 minute
local tick_major_w    = 2
local tick_minor_w    = 1
local tick_r, tick_g, tick_b, tick_a = 1.0, 1.0, 1.0, 0.85

-- Date / Day boxes
local box_x       = cx - 80           -- left edge of boxes
local date_y      = cy + radius + 18  -- top of date box
local day_y       = date_y + 30       -- top of day  box
local box_w       = 160
local box_h       = 22
local box_r       = 6                 -- corner radius
local font_face   = "DejaVu Sans"

-- ── Helper: rounded rectangle ───────────────────────────────
local function rounded_rect(cr, x, y, w, h, r)
    cairo_move_to(cr, x + r, y)
    cairo_line_to(cr, x + w - r, y)
    cairo_arc(cr, x + w - r, y + r,     r, -math.pi/2, 0)
    cairo_line_to(cr, x + w, y + h - r)
    cairo_arc(cr, x + w - r, y + h - r, r,  0,         math.pi/2)
    cairo_line_to(cr, x + r, y + h)
    cairo_arc(cr, x + r,     y + h - r, r,  math.pi/2, math.pi)
    cairo_line_to(cr, x, y + r)
    cairo_arc(cr, x + r,     y + r,     r,  math.pi,   3*math.pi/2)
    cairo_close_path(cr)
end

-- ── Helper: draw a hand ─────────────────────────────────────
local function draw_hand(cr, angle, length, width, r, g, b, a)
    local x2 = cx + length * math.sin(angle)
    local y2 = cy - length * math.cos(angle)
    cairo_move_to(cr, cx, cy)
    cairo_line_to(cr, x2, y2)
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND)
    cairo_set_line_width(cr, width)
    cairo_set_source_rgba(cr, r, g, b, a)
    cairo_stroke(cr)
end

-- ── Main draw function (called by Conky every update) ───────
function conky_clock_draw()
    if conky_window == nil then return end

    -- Create Cairo surface bound to the Conky window
    local cs = cairo_xlib_surface_create(
        conky_window.display,
        conky_window.drawable,
        conky_window.visual,
        conky_window.width,
        conky_window.height
    )
    local cr = cairo_create(cs)

    -- ── Get current time ──────────────────────────────────
    local hours   = tonumber(os.date("%I"))   -- 12-hour
    local minutes = tonumber(os.date("%M"))
    -- (no seconds hand — two-handed clock)

    -- ── 1. Outer ring ─────────────────────────────────────
    cairo_arc(cr, cx, cy, radius, 0, 2 * math.pi)
    cairo_set_line_width(cr, ring_width)
    cairo_set_source_rgba(cr, ring_r, ring_g, ring_b, ring_a)
    cairo_stroke(cr)

    -- ── 2. Tick marks (60 minute marks) ───────────────────
    for i = 0, 59 do
        local angle    = (i / 60) * 2 * math.pi
        local is_major = (i % 5 == 0)           -- every 5 min = hour position
        local t_len    = is_major and tick_major_len or tick_minor_len
        local t_wid    = is_major and tick_major_w  or tick_minor_w

        local x_outer  = cx + radius            * math.sin(angle)
        local y_outer  = cy - radius            * math.cos(angle)
        local x_inner  = cx + (radius - t_len)  * math.sin(angle)
        local y_inner  = cy - (radius - t_len)  * math.cos(angle)

        cairo_move_to(cr, x_outer, y_outer)
        cairo_line_to(cr, x_inner, y_inner)
        cairo_set_line_width(cr, t_wid)
        cairo_set_line_cap(cr, CAIRO_LINE_CAP_BUTT)
        cairo_set_source_rgba(cr, tick_r, tick_g, tick_b, tick_a)
        cairo_stroke(cr)
    end

    -- ── 3. Hour hand ──────────────────────────────────────
    -- Add fractional offset so hour hand moves between hour marks
    local hour_angle = ((hours % 12) / 12 + minutes / 720) * 2 * math.pi
    draw_hand(cr, hour_angle, radius * hh_length, hh_width, hh_r, hh_g, hh_b, hh_a)

    -- ── 4. Minute hand ────────────────────────────────────
    local min_angle  = (minutes / 60) * 2 * math.pi
    draw_hand(cr, min_angle,  radius * mh_length, mh_width, mh_r, mh_g, mh_b, mh_a)

    -- ── 5. Centre dot ─────────────────────────────────────
    cairo_arc(cr, cx, cy, dot_radius, 0, 2 * math.pi)
    cairo_set_source_rgba(cr, dot_r, dot_g, dot_b, dot_a)
    cairo_fill(cr)

    -- ── 6. Date box ───────────────────────────────────────
    local date_str = os.date("%d %b %Y")          -- e.g. "19 Sep 2026"

    -- Box background (semi-transparent dark)
    rounded_rect(cr, box_x, date_y, box_w, box_h, box_r)
    cairo_set_source_rgba(cr, 0, 0, 0, 0.45)
    cairo_fill(cr)

    -- Box border
    rounded_rect(cr, box_x, date_y, box_w, box_h, box_r)
    cairo_set_line_width(cr, 1)
    cairo_set_source_rgba(cr, 1, 1, 1, 0.5)
    cairo_stroke(cr)

    -- Date text
    cairo_select_font_face(cr, font_face,
        CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD)
    cairo_set_font_size(cr, 13)
    cairo_set_source_rgba(cr, 1, 1, 1, 1)
    local te = cairo_text_extents_t:create()
    cairo_text_extents(cr, date_str, te)
    cairo_move_to(cr,
        box_x + (box_w - te.width) / 2 - te.x_bearing,
        date_y + box_h / 2 + te.height / 2)
    cairo_show_text(cr, date_str)

    -- ── 7. Day box ────────────────────────────────────────
    local day_str = os.date("%A")                 -- e.g. "Saturday"

    -- Box background
    rounded_rect(cr, box_x, day_y, box_w, box_h, box_r)
    cairo_set_source_rgba(cr, 0, 0, 0, 0.45)
    cairo_fill(cr)

    -- Box border
    rounded_rect(cr, box_x, day_y, box_w, box_h, box_r)
    cairo_set_line_width(cr, 1)
    cairo_set_source_rgba(cr, 1, 1, 1, 0.5)
    cairo_stroke(cr)

    -- Day text
    cairo_set_font_size(cr, 13)
    cairo_set_source_rgba(cr, 1, 1, 0.6, 1)      -- warm yellow for the day
    cairo_text_extents(cr, day_str, te)
    cairo_move_to(cr,
        box_x + (box_w - te.width) / 2 - te.x_bearing,
        day_y + box_h / 2 + te.height / 2)
    cairo_show_text(cr, day_str)

    -- ── Cleanup ───────────────────────────────────────────
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end

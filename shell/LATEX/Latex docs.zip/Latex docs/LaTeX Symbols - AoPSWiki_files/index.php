/* generated javascript */
var skin = 'aops';
var stylepath = '/Wiki/skins';

/* MediaWiki:Common.js */
/* Any JavaScript here will be loaded for all users on every page load. */

/* MediaWiki:Aops.js */

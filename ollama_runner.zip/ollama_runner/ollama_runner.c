// Last Change: 2025-01-29  Wednesday: 05:51:57 PM

/*
   Program Description:
   This program is a wrapper for Ollama and Ollama-UI.
   It allows you to run Ollama and Ollama-UI in the background.
   It also opens an intuitive webpage in your browser.
*/

/*
  Assisted by Ollama: qwen2.5-coder:3b
  Minor glitches were ironed out by Anthropic Claude Sonnet 2025.01.29
*/

/*
  Installation:
  BASH Shell:
    Open $HOME/.bashrc or $HOME/.bash_aliases with a text editor and
    paste the following line in the beginning:
      export PATH="$HOME/.local/bin/:$PATH"

  Run: source $HOME/.bashrc && source $HOME/.bash_aliases to reload the configuration.

  Fish Shell:
    Open $HOME/.config/fish/config.fish with a text editor and
    paste the following lines in the beginning:
      # --------------
      # $HOME/.local/bin
      export PATH="$HOME/.local/bin/:$PATH"
      export PATH
      # --------------
      Run: source $HOME/.config/fish/config.fish to reload the configuration.

  Now, compile this program:
    gcc -g -Wall -Wextra -pedantic -fstack-protector-all ollama_runner.c -o ollama_runner -s
  Run the commands given below.

  install -m +x ollama_runner $HOME/.local/bin
  mkdir -p $HOME/.config/ollama_runner && cp config.ini $HOME/.config/ollama_runner
  To start Ollama and Ollam-UI, type ollama_runner. The URL will also open in Firefox.
*/

// Restrict to UNIX-like systems only
#if !( defined( __unix__ ) || defined(_POSIX_VERSION) )
  #error "For UNIX-like Operating Systems Only"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // chdir()
#include <ctype.h>   // isspace()

#define  _POSIX_C_SOURCE 200809L
#define  _XOPEN_SOURCE 500L

#define MAX_LINE_LENGTH 256
#define MAX_CMD_LENGTH 1024
#define PATH_MAX 1024

void enter_config_path(void);
void execute_command(const char *command);
void launch_browser(const char *browser_command, const char *url);

// Function to enter $HOME/.config/olama_runner to load configuration from a specified file, config.ini
void enter_config_path(void) {
  // Get home directory
  const char *home_dir = getenv("HOME");

  if(!home_dir) {
    fprintf(stderr, "Failed to get home directory\n");
    exit(EXIT_FAILURE);
  }

  // Construct the full config path
  char config_path[PATH_MAX];
  snprintf(config_path, sizeof(config_path), "%s/.config/ollama_runner", home_dir);
  // Create a directory using mkdir with system() (this is fine as it's not about changing dirs)
  char mkdir_cmd[MAX_CMD_LENGTH];
  snprintf(mkdir_cmd, sizeof(mkdir_cmd) + 2048, "mkdir -p %s", config_path);
  system(mkdir_cmd);

  // Change to the config directory using chdir()
  if(chdir(config_path) != 0) {
    fprintf(stderr, "Failed to change to config directory: %s\n", config_path);
    exit(EXIT_FAILURE);
  }

  // Verify config.ini exists
  if(access("config.ini", F_OK) != 0) {
    fprintf(stderr, "No config file found in %s\n", config_path);
    exit(EXIT_FAILURE);
  }

  // Print current working directory for verification
  char cwd[PATH_MAX];

  if(getcwd(cwd, sizeof(cwd)) != NULL) {
    printf("Current working directory: %s\n", cwd);
  }
}

typedef struct {
  char *ollama_ui_path;
  char *make_command;
  char *browser_command;
  char *url;
} Config;

Config load_config(const char *filename) {
  void enter_config_path(void);
  FILE *file = fopen(filename, "r");

  if(!file) {
    perror("Failed to open config file");
    exit(EXIT_FAILURE);
  }

  Config config = {NULL, NULL, NULL, NULL}; // Initialise all pointers to NULL
  char line[MAX_LINE_LENGTH];
  int section = -1;

  while(fgets(line, sizeof(line), file)) {
    // Trim trailing newline
    char *newline = strchr(line, '\n');

    if(newline) {
      *newline = '\0';
    }

    // Skip empty lines and comments
    if(line[0] == '#' || line[0] == '\0') {
      continue;
    }

    // Determine the section
    if(!strcmp(line, "[Paths]")) {
      section = 1;
      continue;
    }

    else if(!strcmp(line, "[Browser]")) {
      section = 2;
      continue;
    }

    // Parse the key-value pairs
    char *key = line;
    char *value = strchr(line, '=');

    if(!value) {
      fprintf(stderr, "Invalid format in config file: missing '=' in line: %s\n", line);
      fclose(file);
      exit(EXIT_FAILURE);
    }

    // Split key and value
    *value = '\0';  // Terminate key string
    value++;        // Move to start of value

    // Trim whitespace from key and value
    while(isspace(*key)) {
      key++;
    }

    while(isspace(*value)) {
      value++;
    }

    char *end = key + strlen(key) - 1;

    while(end > key && isspace(*end)) {
      *end-- = '\0';
    }

    end = value + strlen(value) - 1;

    while(end > value && isspace(*end)) {
      *end-- = '\0';
    }

    // Assign values to the configuration structure
    if(section == 1) {
      if(!strcmp(key, "ollama-ui-path")) {
        config.ollama_ui_path = strdup(value);

        if(!config.ollama_ui_path) {
          fprintf(stderr, "Memory allocation failed for ollama-ui-path\n");
          fclose(file);
          exit(EXIT_FAILURE);
        }

        // Check if directory exists
        if(access(config.ollama_ui_path, F_OK) != 0) {
          fprintf(stderr, "Invalid ollama-ui-path: No such file or directory: %s\n", config.ollama_ui_path);
          free(config.ollama_ui_path);
          fclose(file);
          exit(EXIT_FAILURE);
        }
      }

      else if(!strcmp(key, "make-command")) {
        config.make_command = strdup(value);

        if(!config.make_command) {
          fprintf(stderr, "Memory allocation failed for make-command\n");
          fclose(file);
          exit(EXIT_FAILURE);
        }
      }
    }

    else if(section == 2) {
      if(!strcmp(key, "browser-command")) {
        config.browser_command = strdup(value);

        if(!config.browser_command) {
          fprintf(stderr, "Memory allocation failed for browser-command\n");
          fclose(file);
          exit(EXIT_FAILURE);
        }
      }

      else if(!strcmp(key, "url")) {
        config.url = strdup(value);

        if(!config.url) {
          fprintf(stderr, "Memory allocation failed for url\n");
          fclose(file);
          exit(EXIT_FAILURE);
        }
      }
    }
  }

  // Verify all required fields are set
  if(!config.ollama_ui_path || !config.make_command ||
     !config.browser_command || !config.url) {
    fprintf(stderr, "Missing required configuration fields\n");
    fclose(file);
    exit(EXIT_FAILURE);
  }

  fclose(file);
  return config;
}

void execute_command(const char *command) {
  char background_cmd[MAX_CMD_LENGTH];
  snprintf(background_cmd, sizeof(background_cmd), "%s &", command);

  if(system(background_cmd)) {
    perror("Failed to execute command");
    exit(EXIT_FAILURE);
  }
}

void launch_browser(const char *browser_command, const char *url) {
  char browser_cmd[MAX_CMD_LENGTH];
#ifdef __linux__
  // On Linux, use nohup to detach the browser process
  snprintf(browser_cmd, sizeof(browser_cmd),
           "nohup %s %s > /dev/null 2>&1 &",
           browser_command, url);
#elif __APPLE__
  // On macOS, use open command
  snprintf(browser_cmd, sizeof(browser_cmd),
           "open -a \"%s\" %s",
           browser_command, url);
#else
  // Default fallback
  snprintf(browser_cmd, sizeof(browser_cmd),
           "%s %s &",
           browser_command, url);
#endif

  if(system(browser_cmd) == -1) {
    fprintf(stderr, "Failed to launch browser: %s\n", browser_cmd);
    // Don't exit on browser launch failure - the server might still be running
  }
}

int main() {
  enter_config_path();
  Config config = load_config("config.ini");

  // Change directory
  if(chdir(config.ollama_ui_path)) {
    perror("Failed to change directory");
    return EXIT_FAILURE;
  }

  // Execute make command
  execute_command(config.make_command);
  // Small delay to allow make to start
  sleep(1);
  // Launch browser in background
  launch_browser(config.browser_command, config.url);
  // Clean up allocated memory
  free(config.ollama_ui_path);
  free(config.make_command);
  free(config.browser_command);
  free(config.url);
  return EXIT_SUCCESS;
}
